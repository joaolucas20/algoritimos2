package questao4;

public class Habitat {
    String tipo;

    public Habitat(String tipo) {
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }
}

package questao3;

public class Professor {
    String nome;

    public Professor(String nome) {
        this.nome = nome;
    }
}
